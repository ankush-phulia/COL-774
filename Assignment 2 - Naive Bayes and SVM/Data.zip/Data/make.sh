sudo apt-get install python-dev
sudo apt-get install python-pip
sudo pip install numpy
sudo pip install nltk
sudo pip install stop_words